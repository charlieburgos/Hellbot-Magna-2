Bucket Magna 2  by DiadelaToalla on Thingiverse: https://www.thingiverse.com/thing:4799681

Summary:

